import React from 'react';

import "./RadialChart.scss";

const RadialChart = () => {
    return (
        <div>
            
        </div>
    );
};

export default RadialChart;